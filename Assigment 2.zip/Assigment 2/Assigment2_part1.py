import nltk
from nltk import WordNetLemmatizer
from nltk.tokenize import word_tokenize
import re
import difflib as diff

import nlmapsgenerated as generated

class Query:
    def __init__(self, query_str):
        self.query_str = query_str

    def parse(self):
        match = re.fullmatch('Where are ([\S\s]+ in ([\S]+)\?', self.query_str)

        if match is None:
            return None
            

        groups = match.groups()
        assert len(groups) == 2, 'Should only match with two groups.'

        subject, location = groups
        result = to_query(subject, location)
        return result


    def to_query(subject, location):
        inner_location = to_inner_location(location)
        inner_subject = to_inner_subject(subject)
        around_location = None

        if type(inner_subject) is tuple and len(inner_subject) > 1:
            inner_subject, around_location = to_inner_subject
        
        inner = f'area({inner_location}), nwr({inner_subject})'

        if around_location is not None:
            body = f'query(around(center({inner}), search(nwr({around_location})), maxdist(DIST_INTOWN)),qtype(latlong))'

        else:
            body = f'query({inner}, qtype(latlong))'
        
        return body
    
    def to_inner_subject(subject):
        patterns = [
            '({)\S+) and (\S)',
            'Indian restaurants' ,
            'Italian restaurants' ,
            '(\S+) supermarkets' ,
            '(\S+) (7:that|with) ([\s\S]+)' ,
            '([\s\S]+)?'

        ]

        pattern_handlers = [
            lambda matches: and_subject(matches[1], matches[2]),
            lambda _: to_key_value('cuisine', 'indian'),
            lambda _: to_key_value('cuisine', 'italian'),
            lambda matches: to_key_value('name', matches[1]),
            lambda matches: subject_with_property(matches[1], matches[2]),
            lambda matches: around_location(matches[1], matches[2]),
            lambda matches: to_default(matches)
        ]

        for matcher, handler in zip(patterns, pattern_handlers):
            subject_match = re.fullmatch(matcher, subject)

            if subject_match is None:
                continue
            
            inner_subject = handler(subject_match)
            return inner_subject

        return None
        

    def to_default(matches):
        subject = matches[0]
        inner_type = to_type(subject)

        if inner_type is not None:
            value = to_tag(subject)
            return to_key_value(inner_type, value)

        return to_key_value('name', subject)
    
    def subject_with_property(subject, property):
        property = to_inner_property(property)
        inner_subject = to_inner_subject(subject)
        return f'{to_inner_subject}, {property}'

    def to_inner_property(property_str):
        properties = [
            '[\s\S]+ wheelchair' ,
            'ATM[\s\S]*',
        ]

        handlers = [
            lambda _: to_key_value('wheelchair', 'yes'),
            lambda _: to_key_value('atm', 'yes')
        ]

        for property, handler in zip(properties, handlers):
            match = re.fullmatch(property, property_str)
            if match is not None:
                return handler(match)

    def to_type(type_str):
        recognized = {
            'amenities': 'amenity',
            'bakeries': 'shop',
            'supermarkets': 'shop',
            'butchers': 'shop',
            'the Stolpersteine': 'memorial:type',
            'tombs': 'historic',
            'camp sites': 'tourism',
            'museums': 'tourism',
            'peaks': 'natural',
            'piers': 'man_made',
            'playgrounds': 'leisure',
            'cemeteries': 'landuse',
            'quarries': 'landuse',
            'bus stops': 'highway',
            'train station': 'railway',
            'subway stations': 'station',
            'fire hydrants': 'emergency',
            'helipads': 'aeroway',
            'infomration maps': 'infromtion',
            'kindergartens': 'amenity',
            'schools': 'amenity',
            'post office': 'amenity',
            'hospitals': 'amenity',
            'charging stations': 'amenity',
            'fire brigades': 'amenity',
            'bike rentals': 'amenity',
            'art centers': 'amenity',
            'banks': 'amenity',
            'murals': 'artwork_type',
            'church': 'place_of_worship',
            'places in which taxis wait': 'amenity',
        }

        if type_str in recognized:
            return recognized[type_str]
        else:
            return None
    
    def to_tag(word_str):
        manual = {
            'the Stolpersteine': 'stolperstein',
            'train station': 'station',
            'subway stations': 'subway',
            'infomration maps': 'map',
            'fire brigades': 'fire_station',
            'bike rentals': 'bicycle_rental',
            'art centers': 'arts_centre',
            'places in which taxis wait': 'taxi'
        }
        if word_str in manual:
            return manual[word_str]

        tokenized = word_tokenize(word_str)
        tag = map(lemmatizer.lemmatize, tokenized)

        return '_'.join(tag)

    def around_location(subject_type, location_subject):
        match = re.fullmatch('(\S+) ([\s\S]+)', location_subject)

        if match is None:
            inner_type = to_type(subject_type)
            return to_key_value(inner_type, '*')

        inner_location = to_inner_location(match[1])
        inner_subject = to_inner_subject(match[2])

        return f'{inner_location},{inner_subject}', to_key_value('amenity', '*')
    
    def and_subject(subject1, subject2):
        s1 = to_inner_subject(subject1)
        s2 = to_inner_subject(subject2)

        if subject2 < subject1:
            s1, s2 = s2, s1

        subjects_str = f'{s1}, {s2}'
        return f'and({subjects_str}'
    
    def to_key_value(key, value):
        return f'keyval(\'{key}\',\'{value}\')'
        
    def to_inner_location(location):
        inner_area = f'keyval(\'name\',\'{location}\')'
        return inner_area


    def read_lines(file_name: str):
        with open(file_name) as file:
            for line in file:
                yield line.strip().rsplit('\t', maxsplit=1)
    
    def accuracy(parsed, truth):
        total = len(truth)
        pairs = zip(parsed, truth)
        correct = sum(map(lambda p: p[0] == p[1], pairs))
        return correct / total
    
    def parse(data):
        for text in data:
            q = Query(text)
            p = q.parse()
            yield p
    
    def test(file_name):
        print('*Testing nlmaps data..')
        data, truth = list(zip(*read_lines(file_name)))
        assert len(data) == len(truth)

        print_first_mismatch(data, truth)

        nlmaps_accuracy = accuracy(parse(data), truth)
        print (f'Accuracy for nlmaps data: {nlmaps_accuracy:%}')

        print('*Done!')

    def test_generated():
        print('*Testing generated data...')
        parsed_generated_queries_count = len(list(parsed_generated()))
        parsed_generated_queries_percent = parsed_generated_queries_count / generated.get_data_size()
        print(f'How many generated queries not translated: {parsed_generated_queries_count} ({parsed_generated_queries_percent:%})')
        print('*Done')

    def parsed_generated():
        for query in generated.get_data():
            try:
                parsed_query = Query(query).parse()
                
                if parsed_query is None:
                    continue
                yield parsed_query
            
            except:
                continue
    
    def print_first_mismatch(data, truth):
        number = 0
        for actual, expected in zip(parse(data), truth):
            number += 1
            if actual != expected:
                print(number)

                adjusted_words = diff_words(actual, expected)

                for w in list(*adjusted_words):
                    new_var = ''.join(w)
                    print(new_var)
                return
    
    def diff_words(actual, expected):
        if actual is None:
            return None
        
        for d, _, l in diff.Differ(),compare(actual, expected):
            if d == ' ':
                pair = l, l
            elif d == '+':
                pair = ' ', l
            elif d == '-':
                pair = l, ' '
            
            yield pair
    lemmatizer = WordNetLemmatizer()

    test('nlmaps.tsv')
    test_generated()
                


