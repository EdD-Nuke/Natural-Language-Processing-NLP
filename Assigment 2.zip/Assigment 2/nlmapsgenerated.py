def get_data():
    pois = ['Japanese restaurants', 'Indian restaurants', 'Italian restaurants', 
'Starbucks', 'bakeries', 'banks', 'bus stops', 'butchers', 
'camp sites', 'cemeteries', 'charging stations', 'fire brigades', 
'fire hydrants', 'helipads', 'hiking maps', 'hospitals', 'kindergartens', 
'museums', 'peaks', 'playgrounds', 'post offices', 'schools', 'supermarkets']

    locations = ['Stockholm', 'Copenhagen', 'Helsinki', 'Oslo', 'Gothenburg', 'Malmö', 
'Tampere', 'Aarhus', 'Turku', 'Bergen', 'Reykjavik']

    test_queries = [f'Where are {poi} in {loc}?' for poi in pois for loc in locations]

    return test_queries

def get_data_size():
    return len(get_data())