from typing import Counter
import nltk
import nltk.grammar
from nltk.corpus.reader.nkjp import NKJPCorpus_Segmentation_View
from nltk.tree import ProbabilisticTree
from pcky import NotCNFGrammarError #<-- Error while handeling pcky, Python version 3.9

#####Taken from papers direlty, I will try to implement on the small batch
#####from the paper as well
#####At least the start for it got lost with the whole part and had some issues with imported packages

def prob_cky(words, grammar):

    for _, betas in grammar:
        if len(betas) > 2:
            raise NotCNFGrammarError()
    
    words_len = len(words)
    counts = Counter()
    listing = dict()

    for j in range (1, words_len+1):
        word = words[j-1] #pointer poiting to top, since it begins from 0
        
        #rhs-matches
        prods = [alpha fro alpha, (b, *_) in grammar if word == b]
        for alpha in prods:
            prob = grammar[alpha, (word,)]
            counts =[j-1, j, alpha] = prob

        for i in range(j-2, (j-1) +1):
            for k in range (i+1, (j-1)+1):
                nont = [ (alpha, beta) for alpha, beta in grammar if len(beta) == 2]
                for prod in nont:
                    A, beta = prod
                    B, C = beta

                    p_b = counts[i, k, B]
                    p_c = counts[k, j, C]

                    if not (p_b > 0 and p_c > 0):
                        continue
                    p = grammar[prod] * p_b * p_c

                    p_a = counts[i, j, A]

                    if (p_a < p):
                        counts[i, j, A] = p
                        listing[i, j, A] = k, B, C
    tree = b_tree(0, words_len, 'S', words, listing, counts)
    prob = counts[0, words_len, 'S']
    return tree

def b_tree(start, end, tag, words, listing, counts):
    k, B, C = listing[start, end, tag]
    children = []
    .....


#####To test the data you would need to use the tes tree with input args:
#####words, rules aka productions through the pcky_grammars
 


