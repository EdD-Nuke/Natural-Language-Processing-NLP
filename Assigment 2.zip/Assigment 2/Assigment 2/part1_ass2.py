
######################
"""Important to explain, i was implementing the assigment but did not have the time for do matching regex
    for all patterns in sentences. There are probably other ways of implementing it shorter."""

import re
import nltk
from typing import NewType

#from Assigment2_part1 import Query

with open('nlmaps.tsv') as f:
    lines = f.readlines()
    f.close

nlmaps = []
for line in lines:
    stripped_line = line.strip('\n')
    sentence, query = stripped_line.split('\t')
    nlmaps.append((sentence, query))

sentences = []
for entry in nlmaps:
    sentence = entry[0]
    sentences.append(sentence)

poi_to_mean = {'amenities': ('amenity', '*'),
            'bakeries': ('shop'),
            'supermarkets': ('shop'),
            'butchers': ('shop'),
            'the Stolpersteine': ('memorial:type'),
            'tombs': ('historic'),
            'camp sites': ('tourism'),
            'museums': ('tourism)',
            'peaks': ('natural'),
            'piers': ('man_made'),
            'playgrounds': ('leisure'),
            'cemeteries': ('landuse'),
            'quarries': ('landuse'),
            'bus stops': ('highway'),
            'train station': ('railway'),
            'subway stations': ('station'),
            'fire hydrants': ('emergency'),
            'helipads': ('aeroway'),
            'infomration maps': ('infromtion'),
            'kindergartens': ('amenity'),
            'schools': ('amenity'),
            'post office': ('amenity'),
            'hospitals': ('amenity'),
            'charging stations': ('amenity'),
            'fire brigades': ('amenity'),
            'bike rentals': ('amenity'),
            'art centers': ('amenity'),
            'banks': ('amenity'),
            'murals': ('artwork_type'),
            'church': ('place_of_worship'),
            'places in which taxis wait': ('amenity')
        }
#  You could make diffrent dicts with diffrent patterns, for eaxmple tags, like 
# to_tag(word_str):
        # manual = {
        #     'the Stolpersteine': 'stolperstein',
        #     'train station': 'station',
        #     'subway stations': 'subway',
        #     'infomration maps': 'map',
        #     'fire brigades': 'fire_station',
#Some kind of accruacy done like this, with two word comp:
# accuracy(parsed, truth):
#         total = len(truth)
#         pairs = zip(parsed, truth)
#         correct = sum(map(lambda p: p[0] == p[1], pairs))
#And then have special cases for some propterities:
#  ['[\s\S]+ wheelchair' ,
#             'ATM[\s\S]*',
#         ]

# And a handler for those cases:
# handlers = [
#             lambda _: to_key_value('wheelchair', 'yes'),
#             lambda _: to_key_value('atm', 'yes')
#         ]
######################

def translate_sentences(sentences, poi_to_mean):
    tra = []
    for sentence in sentences:
        qtype = 'qtype(latlong)'
        whole = []

        p1 = re.compile(r'\sin\s[A-ZÎ][\w-]*')
        m1  = p1.search(sentence)
        if m1 != None:
            match1 = m1.group()
            city = match1[4:]
        
        p2 = re.compile(r'\s(close|no further)\s[\w\s]*\sin\s[A-ZÎ][\w-]*')
        m2 = p2.search(sentence)

        if m2 != None:
            query = f'query(around(center(area(keyval((\'name\', \'{city}\'))'
            whole.append(query)
        
        else:
            query = f'query(area(keyval(\'name\', \'{city}\'))'
            whole.append(query)
        
        p3 = re.compile(r'Where\sare[\w\'\s0-9ÉéÎ]*\sin')
        m3 = p3.search(sentence)
        if m3 != None:
            match3 = m3.group()
            cut_sentence = cut_sentence[0:-10]
        
        p4 = re.compile(r'[A-ZÎ][\w-]*(an|ese)')
        m4 = p4.search(cut_sentence)

        if m4 != None:
            match4=m4.group()
            nationality = match4.lower()
            nwr = f'nwr(keyval(\'cuisine\', \'{nationality}\'))'
            whole.append(nwr)
        
        p5 = re.compile(r'Where\sare\s[A-Z]+[\w]*(\s|\sCity)*(\ssupermarkets)*\sin')
        m5 = p5.search(sentence)

        if m5 != None:
            p6 = re.compile(r'Where\sare\s[A-Z]+[\w]*(\'s|\sCity)*')
            m6 = p6.search(sentence)
            match6 = m6.group()
            proper_name = match6[10:0]
            nwr = f'nwr(keyval(\'name\', \'{proper_name}\'))'
            whole.append(nwr)
        
        if cut_sentence in poi_to_mean:
            if cut_sentence == 'churches' or cut_sentence == 'hiking maps':
                element_1, element_2 = poi_to_mean[cut_sentence][0], poi_to_mean[cut_sentence][1]
                element_3, element_4 = poi_to_mean[cut_sentence][2], poi_to_mean[cut_sentence][3]
                nwr = f'nwr(keyval(\'{element_1}\', \'{element_2}\'), keyval(\'{element_3}\', \'{element_4}\'))'
                whole.append(nwr)
        
        else:
            element_1, element_2 = poi_to_mean[cut_sentence][0], poi_to_mean[cut_sentence][1]
            nwr = f'nwr(keyval(\'{element_1}\', \'{element_2}\'))'
            whole.append(nwr)
        
        if 'taxis' in cut_sentence:
            element_1, element_2 = poi_to_mean['taxis'][0], poi_to_mean['taxis'][1]
            nwr = f'nwr(keyval(\'{element_1}\', \'{element_2}\'))'
            whole.append(nwr)

        whole.append(qtype)
        whole_string = ','.join(whole)
        tra.append(whole_string)
    return tra



def compare_tra( tra, nlmaps):
    counter = 0
    counter_corr = 0

    for i in range (0, len(tra)):
        counter += 1
        if tra[i] == nlmaps[i][1]:
            counter_corr += 1
    accuracy = counter_corr / counter

    print('Num.  sen. translated: ' + str(counter))
    print('Num.  sen. correct: ' + str(counter_corr))
    print('Accuracy: ' + str(accuracy))

if __name__ == 'main':
    tra = translate_sentences(sentences, poi_to_mean)
    compare_tra(tra, nlmaps)

    pois = ['Japanese restaurants', 'Indian restaurants', 'Italian restaurants', 
            'Starbucks', 'bakeries', 'banks', 'bus stops', 'butchers', 
            'camp sites', 'cemeteries', 'charging stations', 'fire brigades', 
            'fire hydrants', 'helipads', 'hiking maps', 'hospitals', 'kindergartens', 
            'museums', 'peaks', 'playgrounds', 'post offices', 'schools', 'supermarkets']

    locations = ['Stockholm', 'Copenhagen', 'Helsinki', 'Oslo', 'Gothenburg', 'Malmö', 
                'Tampere', 'Aarhus', 'Turku', 'Bergen', 'Reykjavik']

    test_queries = [f'Where are {poi} in {loc}?' for poi in pois for loc in locations]

    trans = translate_sentences(test_queries, poi_to_mean)
    for translation in trans:
        print(translation)